package com.digdream.androidrubiksolver.entity;

/**
 * Created by user on 4/6/15.
 */
public class ExpresstionMessage {
    private String msg;
    public String upset;
    public String title;
    public String id;
    public String classify;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getUpset() {
        return upset;
    }

    public void setUpset(String upset) {
        this.upset = upset;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassify() {
        return classify;
    }

    public void setClassify(String classify) {
        this.classify = classify;
    }
}
