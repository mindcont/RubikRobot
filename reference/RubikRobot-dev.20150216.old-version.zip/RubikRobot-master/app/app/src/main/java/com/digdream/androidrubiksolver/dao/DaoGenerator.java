package com.digdream.androidrubiksolver.dao;

/**
 * Created by user on 4/4/15.
 */
public class DaoGenerator {
}
